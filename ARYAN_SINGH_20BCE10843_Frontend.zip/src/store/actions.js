export const addField = (field) => ({
    type: 'ADD_FIELD',
    payload: field,
  });
  
  export const resetFields = () => ({
    type: 'RESET_FIELDS',
  });
  